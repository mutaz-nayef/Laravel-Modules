<?php


return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'password.forget.sent' => 'لقد أرسلنا إليك رابط إعادة تعيين كلمة المرور عبر البريد الإلكتروني',
    'password.reset' => 'تمت إعادة تعيين كلمة مرورك',

];
